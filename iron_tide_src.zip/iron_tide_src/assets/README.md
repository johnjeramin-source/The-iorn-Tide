# Iron Tide Android branding assets

`icon-only.png` and `icon-foreground.png` are the custom Iron Tide coastal-vanguard launcher emblem. The Android workflow feeds these files to `@capacitor/assets` during APK generation. The same mark is used by the PWA icons in `public/`.
