# Iron Tide – Android Release APK

The GitHub Actions workflow builds a signed release APK named `Iron-Tide-release.apk`.

## One-time signing setup

Generate a keystore on your own computer and keep a secure backup:

```bash
keytool -genkeypair -v -keystore iron-tide-release.jks -keyalg RSA -keysize 2048 -validity 10000 -alias irontide
```

Encode the keystore as Base64:
- Linux: `base64 -w 0 iron-tide-release.jks`
- macOS: `base64 iron-tide-release.jks | tr -d '\n'`
- PowerShell: `[Convert]::ToBase64String([IO.File]::ReadAllBytes("iron-tide-release.jks"))`

In GitHub: **Repository → Settings → Secrets and variables → Actions → New repository secret**. Add these four secrets:

- `ANDROID_KEYSTORE_BASE64` – Base64 output of the `.jks` file
- `ANDROID_KEYSTORE_PASSWORD` – keystore password
- `ANDROID_KEY_ALIAS` – alias, e.g. `irontide`
- `ANDROID_KEY_PASSWORD` – key password

Do not commit the keystore or passwords to the repository. Then open **Actions → Build Iron Tide Release APK → Run workflow** and download artifact **Iron-Tide-Release-APK**.

Keep the same keystore for every future update. Losing it may prevent users from updating the installed app. The workflow intentionally stops if signing secrets are missing rather than producing an unsigned release APK.
