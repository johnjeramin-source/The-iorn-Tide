# Part 24 — UI, Graphics & Texture Pass

## Terrain textures (baked once per map, no per-frame cost)
- Ground: soft light/dark mottling, oil/water stains, hairline cracks.
- Roads: darker wheel tracks per lane, patched asphalt, grit, tar cracks, manhole covers.
- Ocean: shallow-water gradient toward the beach, static swell streaks, foam band, seawall edge shading, beach sand grain.
- Canals: water sheen streaks.
- Cost: ~31k canvas calls once when a map first loads (5–35 ms in a mock test; real phone canvas will be slower, expect a brief one-time hitch). Cached afterwards.

## UI textures (CSS only, no new images)
- Brushed-metal hatch + top sheen on the bottom docks, telemetry, player chip, utility rail, and profile card.
- Beveled unit/build/strike buttons and slightly punchier icons.
- Faint scanlines on the title screen.
- Soft vignette over the battlefield while playing/paused (turned off by Battery Saver).

## Bug fix
- Rain/storm was meant to burn fires out ~3x faster, but the engine read `world.weatherKind` (a field that only exists on the HUD snapshot), so it never applied. It now reads `world.weather.kind`. The existing fire test had the same mistake and was corrected. This also clears the `npm run lint` type error.

## Validation
- All 58 game tests pass (tsc transpile + node:test); renderer/engine typecheck clean.
- Terrain bake smoke-tested on 6 maps with a mock canvas (no NaN/invalid arguments).
- Not run here: real-canvas visuals, full Vite build, Android APK. Run `npm install && npm run lint && npm run build`.
