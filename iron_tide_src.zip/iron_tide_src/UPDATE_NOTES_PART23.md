# Part 23 — Achievements System

## New
- 12 achievements (First Contact, Centurion, Exterminator, Rampage, Beachhead Secured, Veteran, No Man Left Behind, Flawless Operation, Blitz, Lifesaver, Final Tide, Boots on the Ground).
- Unlock banner (with haptic buzz if Haptics is on) appears when a mission ends and something is earned.
- Player Profile now has an ACHIEVEMENTS section (locked/unlocked, tap-free, scrolls with the profile).
- Profile tracks total civilians rescued (`rescued`) for the Lifesaver achievement.

## Technical
- `src/game/achievements.ts` holds the list, the unlock rules, and the shared mission-grade formula (the after-action report now uses the same function, so the S–D grade is unchanged).
- `recordRun()` takes an optional 4th argument; old callers still work. Saved profiles from older versions load fine (new fields default to empty).
- Unknown/edited achievement ids in storage are discarded on load.
- No gameplay values, rewards, or balance changed.

## Validation
- `profile.test.ts` extended; all 6 profile tests pass (run via tsc + node:test).
- React components (toast, profile panel) and the full Vite/Android build were NOT run here (no dependencies/network). Run `npm install && npm run lint && npm run build`.
