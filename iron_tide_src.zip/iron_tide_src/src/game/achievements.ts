export type MissionGrade = 'S' | 'A' | 'B' | 'C' | 'D';

/** Stats an achievement can look at: lifetime totals (after this run) plus the run that just ended. */
export interface AchievementContext {
  missions: number;
  victories: number;
  totalKills: number;
  secondsPlayed: number;
  rescued: number;
  run: {
    outcome: 'victory' | 'defeat' | null;
    kills: number;
    seconds: number;
    unitsLost: number;
    grade: MissionGrade;
    campaignMissionId: number | null;
  };
}

export interface AchievementDef {
  id: string;
  icon: string;
  name: string;
  desc: string;
  check: (c: AchievementContext) => boolean;
}

const won = (c: AchievementContext) => c.run.outcome === 'victory';

export const ACHIEVEMENTS: AchievementDef[] = [
  { id: 'first_contact', icon: '☠', name: 'First Contact', desc: 'Eliminate your first infected.', check: (c) => c.totalKills >= 1 },
  { id: 'centurion', icon: '✦', name: 'Centurion', desc: 'Reach 100 total kills.', check: (c) => c.totalKills >= 100 },
  { id: 'exterminator', icon: '⬢', name: 'Exterminator', desc: 'Reach 1,000 total kills.', check: (c) => c.totalKills >= 1000 },
  { id: 'rampage', icon: '🔥', name: 'Rampage', desc: 'Get 150 kills in a single mission.', check: (c) => c.run.kills >= 150 },
  { id: 'first_victory', icon: '✚', name: 'Beachhead Secured', desc: 'Win your first mission.', check: (c) => c.victories >= 1 },
  { id: 'veteran', icon: '★', name: 'Veteran', desc: 'Win 10 missions.', check: (c) => c.victories >= 10 },
  { id: 'no_man_left', icon: '⚑', name: 'No Man Left Behind', desc: 'Win a mission without losing a single unit.', check: (c) => won(c) && c.run.unitsLost === 0 },
  { id: 's_rank', icon: 'S', name: 'Flawless Operation', desc: 'Earn an S grade on a victory.', check: (c) => won(c) && c.run.grade === 'S' },
  { id: 'blitz', icon: '⚡', name: 'Blitz', desc: 'Win a mission in under 5 minutes.', check: (c) => won(c) && c.run.seconds > 0 && c.run.seconds <= 300 },
  { id: 'lifesaver', icon: '♥', name: 'Lifesaver', desc: 'Evacuate 50 civilians in total.', check: (c) => c.rescued >= 50 },
  { id: 'final_tide', icon: '⚓', name: 'Final Tide', desc: 'Win the last campaign mission.', check: (c) => won(c) && c.run.campaignMissionId === 20 },
  { id: 'dedicated', icon: '◷', name: 'Boots on the Ground', desc: 'Play for 1 hour in total.', check: (c) => c.secondsPlayed >= 3600 },
];

export const ACHIEVEMENT_IDS = new Set(ACHIEVEMENTS.map((a) => a.id));

export function achievementById(id: string): AchievementDef | undefined {
  return ACHIEVEMENTS.find((a) => a.id === id);
}

/** Ids that are earned by this context but not in `already`. */
export function evaluateAchievements(c: AchievementContext, already: readonly string[]): string[] {
  const have = new Set(already);
  return ACHIEVEMENTS.filter((a) => !have.has(a.id) && a.check(c)).map((a) => a.id);
}

/** Same formula the after-action report always used (40% sectors, 35% rescue, 25% unit retention). */
export function computeMissionGrade(
  sectorsCaptured: number, sectorsTotal: number,
  civiliansEvacuated: number, civiliansTotal: number,
  unitsAlive: number, unitsLost: number,
): { score: number; grade: MissionGrade } {
  const sectorRatio = sectorsTotal > 0 ? sectorsCaptured / sectorsTotal : 0;
  const rescueRatio = civiliansTotal > 0 ? civiliansEvacuated / civiliansTotal : sectorRatio;
  const unitTotal = unitsAlive + unitsLost;
  const retention = unitTotal > 0 ? unitsAlive / unitTotal : 1;
  const score = Math.round((sectorRatio * 0.4 + rescueRatio * 0.35 + retention * 0.25) * 100);
  const grade: MissionGrade = score >= 92 ? 'S' : score >= 82 ? 'A' : score >= 68 ? 'B' : score >= 52 ? 'C' : 'D';
  return { score, grade };
}
