import React, { useEffect, useState } from 'react';
import { AchievementDef, achievementById } from '../game/achievements';

/** Shows a short banner whenever profile.recordRun unlocks an achievement. */
export const AchievementToast: React.FC<{ onUnlock?: () => void }> = ({ onUnlock }) => {
  const [queue, setQueue] = useState<AchievementDef[]>([]);

  useEffect(() => {
    const handler = (event: Event) => {
      const ids = (event as CustomEvent<{ ids?: string[] }>).detail?.ids ?? [];
      const defs = ids.map(achievementById).filter((a): a is AchievementDef => !!a);
      if (defs.length === 0) return;
      setQueue((current) => [...current, ...defs]);
      onUnlock?.();
    };
    window.addEventListener('irontide-achievements-unlocked', handler);
    return () => window.removeEventListener('irontide-achievements-unlocked', handler);
  }, [onUnlock]);

  const current = queue[0];
  useEffect(() => {
    if (!current) return;
    const t = window.setTimeout(() => setQueue((q) => q.slice(1)), 3600);
    return () => window.clearTimeout(t);
  }, [current]);

  if (!current) return null;
  return (
    <div className="pointer-events-none fixed left-1/2 top-[calc(env(safe-area-inset-top)+10px)] z-[80] -translate-x-1/2" role="status" aria-live="polite">
      <div className="flex items-center gap-3 rounded-lg border border-amber-400/70 bg-slate-950/95 px-4 py-2 shadow-2xl">
        <span className="text-2xl" aria-hidden="true">{current.icon}</span>
        <span className="leading-tight">
          <span className="block text-[10px] font-black uppercase tracking-widest text-amber-300">Achievement unlocked{queue.length > 1 ? ` · +${queue.length - 1} more` : ''}</span>
          <span className="block text-sm font-black text-slate-100">{current.name}</span>
          <span className="block text-[11px] text-slate-400">{current.desc}</span>
        </span>
      </div>
    </div>
  );
};
